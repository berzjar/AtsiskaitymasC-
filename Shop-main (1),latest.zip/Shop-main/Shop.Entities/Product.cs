namespace Shop.Entities
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int CountInStock { get; set; }
        public ICollection<ProductInBasket> ProductInBaskets { get; set; }
    }
}